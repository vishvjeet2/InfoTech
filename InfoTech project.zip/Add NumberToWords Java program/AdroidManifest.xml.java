<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="16dp">

    <Button
        android:id="@+id/startButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Start Timer" />

    <Button
        android:id="@+id/pauseButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Pause Timer"
        android:layout_marginTop="16dp" />

    <Button
        android:id="@+id/resumeButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Resume Timer"
        android:layout_marginTop="16dp" />

</LinearLayout>