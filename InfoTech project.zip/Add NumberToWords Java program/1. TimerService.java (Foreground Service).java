import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;

public class TimerService extends Service {

    private static final String CHANNEL_ID = "TimerChannel";
    private long startTime = 0L;
    private long elapsedTime = 0L;
    private boolean isPaused = false;

    private Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent.getAction();

        if ("START_TIMER".equals(action)) {
            startTime = System.currentTimeMillis() - elapsedTime;
            handler.postDelayed(updateTimerRunnable, 1000);
        } else if ("PAUSE_TIMER".equals(action)) {
            isPaused = true;
            elapsedTime = System.currentTimeMillis() - startTime;
            handler.removeCallbacks(updateTimerRunnable);
        } else if ("RESUME_TIMER".equals(action)) {
            if (isPaused) {
                startTime = System.currentTimeMillis() - elapsedTime;
                handler.postDelayed(updateTimerRunnable, 1000);
                isPaused = false;
            }
        }

        return START_NOT_STICKY;
    }

    private Runnable updateTimerRunnable = new Runnable() {
        @Override
        public void run() {
            long timeNow = System.currentTimeMillis();
            elapsedTime = timeNow - startTime;
            updateNotification();
            handler.postDelayed(this, 1000);
        }
    };

    private void updateNotification() {
        String timeString = formatElapsedTime(elapsedTime);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Timer Running")
                .setContentText("Elapsed Time: " + timeString)
                .setSmallIcon(R.drawable.ic_timer)
                .setOngoing(true) // Makes it persistent
                .build();

        startForeground(1, notification);
    }

    private String formatElapsedTime(long millis) {
        int seconds = (int) (millis / 1000) % 60;
        int minutes = (int) ((millis / (1000 * 60)) % 60);
        int hours = (int) ((millis / (1000 * 60 * 60)) % 24);
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Timer Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}